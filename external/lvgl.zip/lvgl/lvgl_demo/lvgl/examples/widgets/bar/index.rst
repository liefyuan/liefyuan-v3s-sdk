C
^
Simple Bar 
""""""""""""""""

.. lv_example:: widgets/bar/lv_example_bar_1
  :language: c
  
Styling a bar
""""""""""""""""

.. lv_example:: widgets/bar/lv_example_bar_2
  :language: c
  
Temperature meter
""""""""""""""""""

.. lv_example:: widgets/bar/lv_example_bar_3
  :language: c
  
Stripe pattern and range value
""""""""""""""""""""""""""""""""

.. lv_example:: widgets/bar/lv_example_bar_4
  :language: c
  
Bar with RTL and RTL base direction
""""""""""""""""""""""""""""""""""""

.. lv_example:: widgets/bar/lv_example_bar_5
  :language: c

Custom drawr to show the current value
"""""""""""""""""""""""""""""""""""""""

.. lv_example:: widgets/bar/lv_example_bar_6
  :language: c
  
MicroPython
^^^^^^^^^^^

No examples yet.
